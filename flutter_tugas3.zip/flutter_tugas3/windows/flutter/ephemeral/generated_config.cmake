# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\Download\\flutter_windows_3.47.9-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\Download\\flutter_windows_3.47.9-stable\\flutter"
  "PROJECT_DIR=C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3"
  "FLUTTER_ROOT=D:\\Download\\flutter_windows_3.47.9-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3"
  "FLUTTER_TARGET=C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuOQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YzE5N2NhNTE5OQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ODljMzllZGZkZg==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy43"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\M-RDWNPRD\\AppData\\Local\\Temp\\WinGet\\flutter_tugas3\\.dart_tool\\package_config.json"
)
